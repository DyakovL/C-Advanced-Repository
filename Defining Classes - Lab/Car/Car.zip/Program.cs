﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            // TODO: define the Main() method here ...
        }
    }
}
